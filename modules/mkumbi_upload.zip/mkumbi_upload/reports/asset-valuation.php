<?php
require_once __DIR__ . '/_stub_template.php';
render_report_stub('Asset Valuation', 'Current book values.');
