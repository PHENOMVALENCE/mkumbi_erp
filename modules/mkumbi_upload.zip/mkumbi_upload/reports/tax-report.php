<?php
require_once __DIR__ . '/_stub_template.php';
render_report_stub('Tax Report', 'VAT and withholding summaries.');
