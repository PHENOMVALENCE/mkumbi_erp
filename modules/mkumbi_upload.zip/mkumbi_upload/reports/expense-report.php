<?php
require_once __DIR__ . '/_stub_template.php';
render_report_stub('Expense Report', 'Expenses by category and period.');
