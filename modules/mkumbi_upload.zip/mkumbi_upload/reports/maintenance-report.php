<?php
require_once __DIR__ . '/_stub_template.php';
render_report_stub('Maintenance Report', 'Maintenance history and costs.');
